#include <list.h>

struct list frt;
struct frame_entry{
	void *v;
	void *p;
	struct thread* frame_thread;
	struct list_elem elem;
};

void frame_init(void);
struct frame_entry *insert_frame(void *v,void *p,bool wr);
void del_frame(struct frame_entry *f);
struct frame_entry* get_frame_entry(void *p);
