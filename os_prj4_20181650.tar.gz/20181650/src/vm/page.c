#include "page.h"
#include "lib/stdbool.h"
#include "threads/thread.h"
#include "frame.h"
#include <stdio.h>
#include "threads/vaddr.h"
struct page_entry* get_page_entry(struct hash* pgt, void* v) {
	struct page_entry p;
	p.v = pg_round_down(v);
	//if(hash_find(pgt,&p.elem0==NULL)
	return hash_entry(hash_find(pgt, &p.elem), struct page_entry, elem);
}
int pageLess(struct hash_elem *p1,struct hash_elem*p2,void *aux){
	struct page_entry *e1,*e2;
	e1=hash_entry(p1,struct page_entry, elem);
	e2=hash_entry(p2,struct page_entry, elem);
	return (e1->v < e2->v);
	//if(e1->v>=e2->v) return 0; else return 1; 
}

unsigned int pageHash(struct hash_elem *p,void *aux){
	struct page_entry* e=hash_entry(p,struct page_entry, elem);
	return hash_int(&e->v);
}

void init_page_table(struct hash* pgt){
	hash_init(pgt,pageHash,pageLess,0);
}


void insert_page(void* v, void* p, bool wr) {
	struct page_entry* newpage = (struct page_entry*)malloc(sizeof(struct page_entry));
	newpage->v = pg_round_down(v);
	newpage->p = pg_round_down(p);
	newpage->swapnum = -1;
	newpage->wr = wr;

	struct hash* pgt = &thread_current()->pgt;
	hash_insert(pgt, &newpage->elem);
}


int del_page(struct hash *pgt,void *v){
	//struct thread *cur=thread_current();
	struct page_entry *p=get_page_entry(pgt,v);
	if(p==NULL) return 0;
	//printf("asdsadsa");
	hash_delete(pgt,&p->elem);
	return 1;
}

void free_page(struct hash_elem* e,void *aux){
	struct page_entry* p=hash_entry(e,struct page_entry,elem);
	//printf("dasdasda");
	free(p);
}

void page_table_drop(struct hash* pgt){
	hash_destroy(pgt,free_page);
}
