#include <hash.h>
#include <stdbool.h>
struct page_entry{
	void *v;
	void *p;
	int swapnum;
	bool wr;
	//struct hash_elem* e;
	struct hash_elem elem;
};

int pageLess(struct hash_elem *p1,struct hash_elem *p2, void *aux);
unsigned int pageHash(struct hash_elem *p,void *aux);
void init_page_table(struct hash* pgt);
int del_page(struct hash *pgt,void *v);
void insert_page(void *v,void *p,bool wr);
void free_page(struct hash_elem* e,void* aux);
void page_table_drop(struct hash *pgt);
struct page_entry* get_page_entry(struct hash *pgt, void* v);
