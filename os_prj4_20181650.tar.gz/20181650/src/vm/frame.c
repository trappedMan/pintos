#include "frame.h"
#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include "threads/thread.h"
#include "threads/vaddr.h"
#include "page.h"

void frame_init(){
	//initialize frame list
	list_init(&frt);
}

struct frame_entry* get_frame_entry(void* p) {
	struct list_elem* e = list_begin(&frt);
	struct frame_entry* f;
	while (e != list_end(&frt)) {
		f = list_entry(e, struct frame_entry, elem);
		//printf(f->v);	
		if (pg_round_down(p) == f->p) return f;
		e = list_next(e);
	}
	return NULL;	//No such frame
}

struct frame_entry* insert_frame(void *v,void *p,bool wr){
	struct frame_entry *f=(struct frame_entry*)malloc(sizeof(struct frame_entry));
	f->p=pg_round_down(p);
	f->v=pg_round_down(v);
	f->frame_thread=thread_current();
	list_push_back(&frt,&f->elem);	//just push back in the list
	return f;
}

void del_frame(struct frame_entry *f){
	list_remove(&f->elem);
}
