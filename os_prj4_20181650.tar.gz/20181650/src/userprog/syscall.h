#ifndef USERPROG_SYSCALL_H
#define USERPROG_SYSCALL_H
struct lock rw_filelock;
void syscall_init (void);

#endif /* userprog/syscall.h */
