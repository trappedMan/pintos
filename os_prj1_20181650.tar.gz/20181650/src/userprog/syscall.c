#include "userprog/syscall.h"
#include "filesys/filesys.h"
#include <stdio.h>
#include <syscall-nr.h>
#include "threads/interrupt.h"
#include "threads/thread.h"
#include "pagedir.h"
#include "devices/shutdown.h"
#include "threads/vaddr.h"
#include <console.h>
#include "devices/input.h"
#include "process.h"
#include "threads/synch.h"
#include <string.h>
typedef int pid_t;
static void syscall_handler (struct intr_frame *);
void check_addr(uint32_t *esp,int arg_size);


void halt(void);
void exit(int status);
pid_t exec(const char* arg);
int wait(pid_t pid);
int write(int fd,const void* buf,unsigned int size);
int read(int fd,void* buf,unsigned int size);
int fibonacci(int n);
int max_of_four_int(int a,int b,int c,int d);
void
syscall_init (void) 
{
  intr_register_int (0x30, 3, INTR_ON, syscall_handler, "syscall");
}

void check_addr(uint32_t* esp,int arg_size){
	for(int i=0;i<=arg_size;i++){
		if(!(esp+i)){
			//printf("NULL PTR\n");
			exit(-1);
		}

		else if(!is_user_vaddr((void *)esp[i])){
			//printf("Accessing Kernel Address\n");
			exit(-1);
		}
		else if(!pagedir_get_page(thread_current()->pagedir,esp+i)){
			//printf("Paging Error\n");
			exit(-1);
		}
	}
}

static void
syscall_handler (struct intr_frame *f) 
{
	uint32_t* esp32_ptr=(uint32_t*)(f->esp);
	uint32_t sys_num=*(uint32_t*)(f->esp);
	switch(sys_num){
		case SYS_HALT:
			check_addr(esp32_ptr,0);
			halt();	
			break;
		case SYS_EXIT:
			check_addr(esp32_ptr,1);
			exit((int)esp32_ptr[1]);
			break;
		case SYS_EXEC:
			check_addr(esp32_ptr,1);
			f->eax=exec((char *)esp32_ptr[1]);
			break;
		case SYS_WAIT:
			check_addr(esp32_ptr,1);
			f->eax=wait((pid_t)esp32_ptr[1]);
			break;
		case SYS_READ:
			check_addr(esp32_ptr,3);
			f->eax=read((int)esp32_ptr[1],esp32_ptr[2],(unsigned int)esp32_ptr[3]);
			break;
		case SYS_WRITE:
			check_addr(esp32_ptr,3);
			f->eax=write((int)esp32_ptr[1],esp32_ptr[2],(unsigned int)esp32_ptr[3]);
			break;
		case SYS_FIBO:
			check_addr(esp32_ptr,1);
			f->eax=fibonacci((int)esp32_ptr[1]);
			break;
		case SYS_MAXFOUR:
			check_addr(esp32_ptr,4);
			f->eax=max_of_four_int((int)esp32_ptr[1],(int)esp32_ptr[2],(int)esp32_ptr[3],(int)esp32_ptr[4]);
			break;
		//default:
		//	exit(-1);
	}
}
//implementations of syscall functions
void halt(){
	shutdown_power_off();
}

void exit(int status){
	thread_current()->exit_status=status;
	const char* name=thread_current()->name;
	char proc_name[200];
	int i;
	for(i=0;i<(int)strlen(name);i++){
		if(name[i]==' ')
			break;
	}
	strlcpy(proc_name,name,i+1);
	printf("%s: exit(%d)\n",proc_name,status);
	thread_exit();
}

pid_t exec(const char* arg){
	char str[200];
	int i=0;
	while(arg[i]!=' '){
		i++;
	}
	strlcpy(str,arg,i+1);
	if(filesys_open(str)==NULL)
		return -1;
	return (pid_t)process_execute(arg);	
}

int wait(pid_t pid){
	return process_wait(pid);
}

int write(int fd,const void* buf,unsigned int size){
	if(fd!=1)
	   return -1;
	putbuf(buf,size);	
	return size;
}

int read(int fd,void *buf,unsigned int size){
	if(fd!=0)
		return -1;
	int i;
	for(i=0;i<size;i++){
		if(input_getc()){
			*(char *)buf=(char)input_getc();
			buf++;
		}
	}	
	return i;
}

int fibonacci(int n){
	if(n==1||n==2)
		return 1;
	int f=1,s=1,nxt=1;
	while(n-->2){
		nxt=f+s;
		f=s;
		s=nxt;
	}
	return nxt;
}

int max_of_four_int(int a,int b,int c,int d){
	int tmp=a;
	if(tmp<b)
		tmp=b;
	if(tmp<c)
		tmp=c;
	if(tmp<d)
		tmp=d;
	return tmp;
}














